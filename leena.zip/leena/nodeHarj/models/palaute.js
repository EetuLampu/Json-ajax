var db = require('../lib/dbconn'); //reference of dbconnection.js 

var Palaute = { 
    getAllPalaute: function(callback) { 
    return db.query("select * from palauteapp_palaute", callback); 
  }, 
  getPalauteById: function(id, callback) { 
    return db.query("select * from palauteapp_palaute where palauteID=?", [id], callback); 
  }, 
  addPalaute: function(Palaute, callback) { 
    return db.query("insert into palauteapp_palaute values(?,?,?,?)", [Palaute.date, Palaute.otsikko, Palaute.teksti, Palaute.nimi], callback); 
  }, 
  deletePalaute: function(id, callback) { 
    return db.query("delete from palauteapp_palaute where palauteID=?", [id], callback); 
  }
}; 
module.exports = Palaute;