class Tulokset extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
	   error: null,
	   isLoaded: false,
	   tulokset: [],
        value: 'Tyhja', 
    };
      this.tuoteVaihdin = this.tuoteVaihdin.bind(this);
  }
    
    tuoteVaihdin(event) {
        this.setState({value: event.target.value});
        if (event.target.value=="Tyhja") {
            fetch("http://magnesium/dat16syst/eetu.lampu/leena/ajax/heaTuotteet.php")
            .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                tulokset: result
              });
            },
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
        }
        else if (event.target.value=="Jalosteet") {
          fetch("http://magnesium/dat16syst/eetu.lampu/leena/ajax/haeJalosteet.php")
          .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                tulokset: result
              });
            },
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
        }
        else if (event.target.value=="Juomat") {
          fetch("http://magnesium/dat16syst/eetu.lampu/leena/ajax/haeJuomat.php")
          .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                tulokset: result
              });
            },
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
        }
        else if (event.target.value=="Kalatuotteet") {
            fetch("http://magnesium/dat16syst/eetu.lampu/leena/ajax/haeKalatuotteet.php")
          .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                tulokset: result
              });
            },
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
        }
        else if (event.target.value=="Lihatuotteet") {
            fetch("http://magnesium/dat16syst/eetu.lampu/leena/ajax/haeLihatuotteet.php")
          .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                tulokset: result
              });
            },
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
        }
        else if (event.target.value=="Maitotuotteet") {
            fetch("http://magnesium/dat16syst/eetu.lampu/leena/ajax/haeMaitotuotteet.php")
          .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                tulokset: result
              });
            },
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
        }
        else if (event.target.value=="Makeiset") {
            fetch("http://magnesium/dat16syst/eetu.lampu/leena/ajax/haeMakeiset.php")
          .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                tulokset: result
              });
            },
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
        }
        else if (event.target.value=="Mausteet") {
            fetch("http://magnesium/dat16syst/eetu.lampu/leena/ajax/haeMausteet.php")
          .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                tulokset: result
              });
            },
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
        }
        else if (event.target.value=="Viljatuotteet") {
            fetch("http://magnesium/dat16syst/eetu.lampu/leena/ajax/haeViljatuotteet.php")
          .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                tulokset: result
              });
            },
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
        } 
    }
  
  componentDidMount() {
    fetch("http://magnesium/dat16syst/eetu.lampu/leena/ajax/heaTuotteet.php")
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            isLoaded: true,
            tulokset: result
          });
        },
        (error) => {
          this.setState({
            isLoaded: true,
            error
          });
        }
      )
  }
    
    render() {
        const { error, isLoaded, tulokset } = this.state;
        if (error) {
            return <div>Error: {error.message}</div>;
        } 
        else if (!isLoaded) {
            return <div>Loading...</div>;
        } 
        else {
            return (
                <div>
                    <select onClick={this.tuoteVaihdin}>
                        <option value="Tyhja">Valitse tuoteryhmä</option>
                        <option value="Jalosteet">Jalosteet</option>
                        <option value="Juomat">Juomat</option>
                        <option value="Kalatuotteet">Kalatuotteet</option>
                        <option value="Lihatuotteet">Lihatuotteet</option>
                        <option value="Maitotuotteet">Maitotuotteet</option>
                        <option value="Makeiset">Makeiset</option>
                        <option value="Mausteet">Mausteet </option>
                        <option value="Viljatuotteet">Viljatuotteet</option>
                    </select>
                    <table>
                        <tr>
                            <th>TuoteID</th>
                            <th>Tuotenimi</th>
                            <th>Toimittaja</th>
                            <th>Ryhmä</th>
                            <th>Määrä</th>
                            <th>Yksikköhinta</th>
                        </tr>
                        {tulokset.map(tulos => (
                        <tr>
                            <td>{tulos.Tuoteid}</td>
                            <td>{tulos.Tuotenimi}</td>
                            <td>{tulos.Toimittaja}</td>
                            <td>{tulos.Ryhma}</td>
                            <td>{tulos.Maara}</td>
                            <td>{tulos.Yksikkohinta}</td>
                        </tr>))}
                    </table>
                </div>
            );
        }
    }
}

ReactDOM.render(<Tulokset/>, document.getElementById("kaksi"));
